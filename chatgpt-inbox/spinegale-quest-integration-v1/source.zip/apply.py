"""Apply the Spinegale production release to Kari. Python 3.10+, no network.
Default: preflight/dry run. --apply writes only after all checks pass.
Run from release folder: python apply.py /path/to/Kari --apply
"""
from pathlib import Path
import argparse, json, shutil, sys, re, hashlib, subprocess, copy
P=Path(__file__).resolve().parent;D=P/'data';BASE='monster.spinegale';MARK='// spinegale integration v1'

def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('repo',type=Path);ap.add_argument('--apply',action='store_true');ap.add_argument('--test',action='store_true');ap.add_argument('--mobile',action='store_true',help='use the earlier 32k LOD instead of the V3 171k model');args=ap.parse_args();root=args.repo.resolve();pending={}
 def read(p):return pending.get(p,(root/p).read_bytes()).decode('utf-8') if (root/p).exists() else pending[p].decode('utf-8')
 def obj(p):return json.loads(read(p))
 def data(p):return json.loads((D/p).read_text(encoding='utf-8'))
 def put(p,s):pending[p]=s.encode('utf-8') if isinstance(s,str) else s
 def jput(p,j):put(p,json.dumps(j,ensure_ascii=False,indent=2)+'\n')
 def add_unique(items,entry,key='id'):
  i=next((i for i,x in enumerate(items) if x[key]==entry[key]),None)
  if i is None:items.append(entry)
  else:items[i]=entry
 def patch(p,a,b):
  s=read(p)
  if b in s:return
  if s.count(a)!=1:raise RuntimeError(f'Patch anchor changed or duplicated: {p}: {a[:90]}')
  put(p,s.replace(a,b,1))
 def append_file(files,k,v):
  if isinstance(files[k],str):files[k]=[files[k]]
  if v not in files[k]:files[k].append(v)
 if not (root/'AGENTS.md').exists() or not (root/'public/data/content.json').exists():raise RuntimeError('Kari root required')
 index=obj('public/data/content.json');files=index['files'];
 for k,src,dst in [('monsters','monster.json','monsters/spinegale.json'),('actions','actions.json','actions/spinegale.json'),('tracks','tracks.json','tracks/spinegale.json'),('curves','curves.json','curves_spinegale.json'),('follow','follow.json','follow/spinegale.json'),('items','items.json','items_spinegale.json'),('loot','loot.json','loot_spinegale.json'),('quests','quests.json','quests_spinegale.json')]:
  put('public/data/'+dst,(D/src).read_bytes());append_file(files,k,dst)
 families={f['id'] for f in obj('public/data/'+files['weapons'])['families']};all_eq=data('equipment_all.json');eq=copy.deepcopy(all_eq);eq['weapons']=[w for w in eq['weapons'] if w['family'] in families];active={w['id'] for w in eq['weapons']};eq['recipes']=[r for r in eq['recipes'] if 'resultWeaponId' not in r or r['resultWeaponId'] in active];jput('public/data/equipment_spinegale.json',eq);append_file(files,'equipment','equipment_spinegale.json');jput('public/data/content.json',index)
 board_path='public/data/'+files['board'];board=obj(board_path)
 for b in data('board.json'):add_unique(board['quests'],b,'questId')
 jput(board_path,board)
 field='public/data/fields/basin.json';b=obj(field);b['routes'][BASE]={'start':'a3','roam':['a3','a7','a4','a2'],'nest':'a10'};jput(field,b)
 # Preserve existing bestiary number assignments. Add at end, not replace Selvark.
 bestpath='public/data/'+files['bestiary'];be=obj(bestpath);old=next((s for s in be['species'] if s['id']==BASE),None)
 sp={'id':BASE,'no':old['no'] if old else max(s['no'] for s in be['species'])+1,'title':'疾棘竜','name':'スパインゲイル','class':'large','variant':'base','rank':'rank.1','frame':'frame.biped_wing','size':6.3,'habitat':'風礫盆地','elements':['none'],'statuses':[],'weak':['ice','water'],'resist':[],'look':'黄黒の縞、橙の喉袋、背棘、二股の尾扇','organ':'放熱する喉皮膜と尾扇、瞬発力の高い後脚。','moves':['高速突進','二連噛みつき','跳躍蹴り','尾薙ぎ','長い息切れ'],'parts':['頭','喉袋','後脚','背棘','尾扇'],'materials':['疾棘竜の鱗','疾棘竜の鋭爪','疾棘竜の背棘','疾棘竜の喉膜','疾棘竜の尾扇','疾棘竜の弾性腱'],'gear':'会心・軽量・回避と息継ぎ。','armorLook':'黄黒の鱗、背棘と喉膜、二股の腰布。','ecology':{'diet':'小型動物を捕食する。','behavior':'高速走行の後は放熱のため停止する。','territory':'盆地の乾いた岩場。','rhythm':'朝夕に活動し日中は岩陰で休む。','nest':'風通しの良い岩棚。','relations':'小型の群れを率いる。幼体の実装は別途。','juvenile':'尾扇と冠棘が小さい。','signs':'三趾の足跡と制動時の爪痕。'},'state':'implemented','stateNote':'初級〜上級の狩猟と専用疲労行動。','source':'ユーザー採用案D / Spinegale release v1','art':'spinegale_concept_v1.png'}
 add_unique(be['species'],sp);be['species'].sort(key=lambda x:x['no']);be['plan']['rank.1']=max(be['plan'].get('rank.1',0),sum(s['rank']=='rank.1' and s['class']!='juvenile' for s in be['species']));jput(bestpath,be)
 # New model, 69 icons (all three ranks), 1 concept image. Keep binary in the local install pack, not in GitHub's text submission.
 mdl='spinegale_mobile.glb' if args.mobile else 'spinegale_v3_game.glb';model=(P/'models'/mdl).read_bytes();put('public/assets/models/monsters/spinegale_v3_game.glb',model)
 for id,path in data('icon_index.json').items():put('public/assets/icons/spinegale/'+path,(P/'icons'/path).read_bytes())
 put('public/assets/monsters/spinegale_concept_v1.png',(P/'reference.png').read_bytes());put('art-source/spinegale_concept_v1.png',(P/'reference.png').read_bytes())
 # Schema/level scaling are scoped to this new species. Existing ranks unaffected.
 p='src/data/schemas.ts';patch(p,'export interface MonsterDef {','export interface MonsterDef {\n  /** Spinegale-specific rank used by the deterministic fatigue scheduler. */\n  spinegaleRank?: number;')
 p='src/game/rank.ts';patch(p,'    hp: Math.max(1, Math.round(def.hp * s.hpScale)),','    ...(def.id === "monster.spinegale" ? { spinegaleRank: rank.order, moveSpeed: [2.8, 3.0, 3.2][Math.min(2,rank.order-1)] } : {}),\n    hp: def.id === "monster.spinegale" ? [1450, 3200, 5800][Math.min(2,rank.order-1)]! : Math.max(1, Math.round(def.hp * s.hpScale)),')
 p='src/game/monster.ts';patch(p,'export interface MonsterState {','export interface MonsterState {\n  spinegale?: { stamina: number; remaining: number; max: number; restTicks: number; rank: number };')
 patch(p,'    def,\n    pos,','    def,\n    ...(def.id === "monster.spinegale" ? { spinegale: spinegaleState(def.spinegaleRank ?? 1) } : {}),\n    pos,')
 costs=data('stamina_costs.json');costliteral=json.dumps(costs,ensure_ascii=False)
 helper=f'''{MARK}
const SG_COST: Record<string, number> = {costliteral};
function spinegaleState(rank: number) {{
  const i=Math.max(0,Math.min(2,rank-1));
  const max=[100,120,140][i]!;
  return {{ stamina:max, remaining:0, max, restTicks:[600,540,480][i]!, rank:i+1 }};
}}
function spinegaleFatigueId(rank:number):string {{ return 'monster.spinegale.'+(rank===1?'fatigue_full':'fatigue_r'+rank); }}
function sgFatigueAction(id:string|undefined):boolean {{ return !!id&&id.startsWith('monster.spinegale.fatigue_'); }}
'''
 patch(p,'function begin(m: MonsterState, actionId: string, ctx: SimCtx): void {',helper+'\nfunction begin(m: MonsterState, actionId: string, ctx: SimCtx): void {\n  if (m.spinegale) {\n    const cost=SG_COST[actionId.slice("monster.spinegale.".length)] ?? 0;\n    m.spinegale.stamina=Math.max(0,m.spinegale.stamina-cost*(m.enraged?1.2:1));\n  }')
 patch(p,'      dist >= c.minDist &&','      (!m.spinegale || m.spinegale.rank >= 2 || !c.actionId.endsWith(".triple_dash")) &&\n      dist >= c.minDist &&')
 patch(p,'  if (m.captured) return;\n  if (m.tranqTicks','  if (m.captured) return;\n  if (m.spinegale && m.spinegale.remaining > 0) {\n    if (--m.spinegale.remaining === 0) {\n      m.spinegale.stamina=m.spinegale.max;\n      if(sgFatigueAction(m.action?.def.actionId)) m.action=null;\n    }\n  }\n  if (m.tranqTicks')
 patch(p,'  // 群れの幼体: ふだんは群れの動き。','  // Fatigue survives hit reactions, traps, status effects, rage, and area changes.\n  if (m.spinegale && m.spinegale.remaining > 0) {\n    if (!sgFatigueAction(m.action?.def.actionId)) begin(m,spinegaleFatigueId(m.spinegale.rank),ctx);\n    if (m.action) { m.action.tick=m.spinegale.restTicks-m.spinegale.remaining+1; m.action.advanced=true; }\n    return;\n  }\n  // 群れの幼体: ふだんは群れの動き。')
 patch(p,'    if (m.pendingRoar && def.rage) {','    if (m.spinegale && active && m.spinegale.stamina <= 20) {\n      m.spinegale.remaining=m.spinegale.restTicks;\n      begin(m,spinegaleFatigueId(m.spinegale.rank),ctx);\n    } else if (m.pendingRoar && def.rage) {')
 # Bind model to the same sim state/action time; never apply horizontal root motion twice.
 p='src/render/view.ts';patch(p,"import { GaldrosRig } from './galdrosRig';","import { GaldrosRig } from './galdrosRig';\nimport { SpinegaleRig } from './spinegaleRig';")
 patch(p,'const rig: MonsterRig = plan ? new CreatureRig(plan, ids)', 'const rig: MonsterRig = m.def.id === "monster.spinegale" ? new SpinegaleRig() : plan ? new CreatureRig(plan, ids)')
 put('src/render/spinegaleRig.ts',(P/'SpinegaleRig.ts').read_bytes())
 # Native icon API works for existing calls. Additional dedicated weapon/armor icon uses may require UI follow-up.
 p='src/ui/icons.ts';patch(p,'export function iconUrl(id: string): string | null {','const SG_ICONS: Readonly<Record<string,string>> = '+json.dumps(data('icon_index.json'),ensure_ascii=False)+';\nexport function iconUrl(id: string): string | null {\n  if (SG_ICONS[id]) return assetUrl("assets/icons/spinegale/"+SG_ICONS[id]);')
 p='src/ui/questReception.ts';anchor="export function monsterQuestImageUrl(content: Pick<Content, 'bestiary'>, monsterId: string): string | null {";patch(p,anchor,anchor+'\n  if (monsterId === "monster.spinegale") return assetUrl("assets/monsters/spinegale_concept_v1.png");')
 # Metadata registry. No claim of final integration until real tests run.
 p='docs/asset-manifest.json';a=obj(p);add_unique(a['assets'],{'id':'model.monster.spinegale','name':'疾棘竜 スパインゲイル','type':'model','use':'初級〜上級','owner':'ChatGPT','status':'concept','version':1,'path':'public/assets/models/monsters/spinegale_v3_game.glb','source':'original V3 LOD','terms':'本作オリジナル','dims':'m / Y上 +Z前','bones':'77','tris':'32074 mobile' if args.mobile else '171772','clips':[c['name'] for c in json.loads((P/'models/model_manifest_v3_game.json').read_text())['clips']],'verification':'GLB構造と軌道検査済み。ゲーム実機未確認。'});jput(p,a)
 # Explicitly update brittle tests for counts and new quest prerequisites. Refuse a drifted anchor instead of silently rewriting unrelated tests.
 p='tests/rank.test.ts'
 patch(p,'expect(first.filter((q) => !q.targets)).toHaveLength(11);','expect(first.filter((q) => !q.targets)).toHaveLength(12);')
 patch(p,'for (const q of first) expect(q.requires ?? []).toEqual([]);','for (const q of first) expect(q.requires ?? []).toEqual(q.id === "quest.spinegale.r1" ? ["quest.basin.003"] : []);')
 patch(p,"'quest.selvark.r2', 'quest.selvark.r3', 'quest.selvark.r4']);","'quest.selvark.r2', 'quest.selvark.r3', 'quest.selvark.r4', 'quest.spinegale.r2', 'quest.spinegale.r3']);")
 patch(p,'for (const q of upper) expect(q.requires, q.id).toEqual([gate[q.rankId]]);','for (const q of upper) expect(q.requires, q.id).toEqual(q.id.startsWith("quest.spinegale.") ? [gate[q.rankId], q.rankId === "rank.2" ? "quest.spinegale.r1" : "quest.spinegale.r2"] : [gate[q.rankId]]);')
 patch(p,'toEqual([118, 5]);','toEqual([121, 5]);');patch(p,'44 + 23 + 15 + 19 * 5);','44 + 23 + 15 + 19 * 5 + 6);')
 p='tests/bestiary.test.ts'
 patch(p,'expect(b.species.length).toBe(86);','expect(b.species.length).toBe(87);')
 patch(p,"expect(b.species.filter((s) => s.class !== 'juvenile').length).toBe(78);","expect(b.species.filter((s) => s.class !== 'juvenile').length).toBe(79);")
 patch(p,"expect(b.species.filter((s) => s.state === 'implemented').map((s) => s.no)).toEqual([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 14, 15, 16, 17, 18, 19, 20, 21]);","expect(b.species.filter((s) => s.state === 'implemented').map((s) => s.no)).toEqual([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 14, 15, 16, 17, 18, 19, 20, 21, 87]);")
 patch(p,'expect(b.species.map((s) => s.no)).toEqual(Array.from({ length: 86 }, (_, i) => i + 1));','expect(b.species.map((s) => s.no)).toEqual(Array.from({ length: 87 }, (_, i) => i + 1));')
 patch(p,"expect(content.bestiary.plan).toEqual({ 'rank.1': 13, 'rank.2': 20, 'rank.3': 25, 'rank.4': 20 });","expect(content.bestiary.plan).toEqual({ 'rank.1': 14, 'rank.2': 20, 'rank.3': 25, 'rank.4': 20 });")
 patch(p,'expect(c.map((x) => [x.have, x.plan])).toEqual([[13, 13], [20, 20], [25, 25], [20, 20]]);','expect(c.map((x) => [x.have, x.plan])).toEqual([[14, 14], [20, 20], [25, 25], [20, 20]]);')
 patch(p,'expect(c[0]).toMatchObject({ have: 13, juveniles: 9 });','expect(c[0]).toMatchObject({ have: 14, juveniles: 9 });')
 patch(p,'expect(content.bestiary.species.length).toBe(86);','expect(content.bestiary.species.length).toBe(87);')
 patch(p,'expect(r.bestiary.species.length).toBe(86);','expect(r.bestiary.species.length).toBe(87);')
 patch(p,'登録簿は決まりどおりです（86 種、狩場の案 20）','登録簿は決まりどおりです（87 種、狩場の案 20）')
 # Other fixture expectations depend on version/fixture and are deliberately not blanket-replaced.
 # Validate crossreferences for package's own records before writing anything.
 from validate import verify
 verify(P)
 print('preflight:',len(pending),'files;',len(eq['weapons']),'active weapons / 33 total;',len(eq['armor']),'armor; 3 quests; 21 materials; 69 icons')
 if not args.apply:
  print('Dry run only. Use --apply on a clean integration branch.');return
 # Stage files, avoid partial writes if anchors or assets are missing; backup replaced files locally.
 backup=root/'.spinegale-backup';backup.mkdir(exist_ok=True)
 for p,v in pending.items():
  path=root/p;old=path.read_bytes() if path.exists() else None
  if old==v:continue
  if old is not None:
   dst=backup/p;dst.parent.mkdir(parents=True,exist_ok=True)
   if not dst.exists():dst.write_bytes(old)
  path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(v)
 print('Applied to working tree (not committed).')
 if args.test:
  for cmd in [['npm','run','typecheck'],['npm','test'],['npm','run','build']]:subprocess.run(cmd,cwd=root,check=True,shell=sys.platform=='win32')
if __name__=='__main__':main()
