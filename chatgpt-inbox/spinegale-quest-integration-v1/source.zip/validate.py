"""Independent package-level validation (no Kari runtime required)."""
from pathlib import Path
import json, struct, math, hashlib

def verify(root):
 root=Path(root);data=root/'data';read=lambda n:json.loads((data/n).read_text());d=read('monster.json');a=read('actions.json')['actions'];t=read('tracks.json')['tracks'];c=read('curves.json')['curves'];f=read('follow.json');m=read('items.json')['materials'];l=read('loot.json')['tables'];q=read('quests.json')['quests'];b=read('board.json');e=read('equipment_all.json');icons=read('icon_index.json');A={x['actionId']:x for x in a};T={x['id']:x for x in t};C={x['id']:x for x in c};M={x['id']:x for x in m};Q={x['id']:x for x in q};L={x['id']:x for x in l};parts={p['id']:p for p in d['parts']};eq={x['id']:x for x in e['weapons']+e['armor']}
 assert (len(a),len(t),len(c),len(m),len(q),len(e['weapons']),len(e['armor']),len(e['recipes']),len(icons))==(23,13,10,21,3,33,15,48,69)
 assert len(A)==len(a) and len(T)==len(t) and len(C)==len(c) and len(M)==len(m) and len(Q)==len(q) and len(eq)==48
 # exact phase coverage, clip exists, track keys finite and contiguous, move curves valid
 model=root/'models/spinegale_v3_game.glb';raw=model.read_bytes();magic,v,total=struct.unpack_from('<4sII',raw);assert (magic,v,total)==(b'glTF',2,len(raw));n,kind=struct.unpack_from('<I4s',raw,12);assert kind==b'JSON';g=json.loads(raw[20:20+n]);assert len(g['skins'][0]['joints'])==77 and len(g['animations'])==53;clips={z['name']:z for z in g['animations']};tri=sum(g['accessors'][p['indices']]['count']//3 for p in g['meshes'][0]['primitives']);assert tri==171772
 for x in a:
  D=x['durationTicks'];assert x['clip'] in clips and x['tickRate']==60 and D>0
  assert x['phases'][0]['from']==0 and x['phases'][-1]['to']==D
  assert all(p['from']<p['to'] and (i==0 or x['phases'][i-1]['to']==p['from']) for i,p in enumerate(x['phases']))
  for w in x['hitWindows']:
   assert 0<=w['from']<w['to']<=D and w['shapeTrack'] in T and len(T[w['shapeTrack']]['keys'])==D+1
  if x['rootMotion']['mode']=='controller':assert x['rootMotion']['curveId'] in C and C[x['rootMotion']['curveId']]['keys'][-1][0]==D
  if '.fatigue_' in x['actionId']:assert not x['hitWindows'] and x['rootMotion']['mode']=='none' and D in (600,540,480)
  else:assert clips[x['clip']]['extras']['durationTicks']==D
 for x in t:
  assert x['to']>x['from'] and x['radius']>0 and all(k['t']==i for i,k in enumerate(x['keys']))
  for k in x['keys']:assert all(math.isfinite(y) for y in k['grip']+k['dir']) and abs(sum(y*y for y in k['dir'])-1)<.001
 def check_shapes(sh,D):
  for z in sh:
   p=parts[z['part']];S=p['sever']['shapesAfter'] if z.get('after') else p['shapes'];assert 0<=z['i']<len(S)
   assert len(z['d'])==math.ceil((D-1)/f['step'])+1 and all(len(x)==6 and all(isinstance(v,int) and abs(v)<2000 for v in x) for x in z['d'])
 for id,z in f['actions'].items():check_shapes(z['shapes'],A[id]['durationTicks'])
 assert set(f['actions'])==set(A)
 for z in f['states'].values():check_shapes(z['shapes'],z['ticks'])
 check_shapes(f['poses']['sleep']['shapes'],1)
 for choice in d['ai']['choices']:
  assert choice['actionId'] in A
  if 'ifSevered' in choice:assert choice['ifSevered']['actionId'] in A and choice['ifSevered']['partId'] in parts
 assert d['discover']['actionId'] in A and d['rage']['actionId'] in A and sum(p.get('head',False) for p in parts.values())==1
 obtainable=set()
 for i,z in enumerate(l,1):
  for roll in [z['carve'],z['capture'],*z['breaks'].values(),*z['severed'].values()]:
   assert roll['count']>0 and sum(y['weight'] for y in roll['table'])==100
   for y in roll['table']:assert y['itemId'] in M and y['itemId'].endswith('.r'+str(i));obtainable.add(y['itemId'])
  assert set(z['breaks'])|set(z['severed'])<=set(parts)
 for i,z in enumerate(q,1):
  assert z['rankId']==f'rank.{i}' and z['targetMonsterId']==d['id'] and z['id']==b[i-1]['questId']
  assert b[i-1]['clearMinutes'][1]*3600<=z['fieldTimeLimitTicks']
  for y in z['rewards']['items']:assert y['itemId'] in M and y['itemId'].endswith('.r'+str(i));obtainable.add(y['itemId'])
 assert obtainable==set(M)
 for r in e['recipes']:
  id=r.get('resultWeaponId') or r.get('resultArmorId');assert id in eq and all(i['itemId'] in M and i['itemId'].split('.')[-1]==id.split('.')[-1] and i['count']>0 for i in r['cost']['items'])
  old=r.get('fromWeaponId') or r.get('fromArmorId');assert old in eq if old else id.endswith('.r1')
 assert set(icons)==set(M)|set(eq)
 for key,path in icons.items():
  raw=(root/'icons'/path).read_bytes();assert raw[:8]==b'\x89PNG\r\n\x1a\n' and struct.unpack_from('>II',raw,16)==(256,256) and raw[25]==6,(key,path)
 return {'status':'PASS','scope':'package structure, all data references, PNG headers, GLB clips and triangles, fatigue duration, animation follow tables','quests':len(q),'materials':len(m),'weapons':len(e['weapons']),'armor':len(e['armor']),'recipes':len(e['recipes']),'icons':len(icons),'actions':len(a),'attackTracks':len(t),'followActions':len(f['actions']),'triangles':tri,'joints':77,'clips':53,'modelSha256':hashlib.sha256(model.read_bytes()).hexdigest(),'runtime':'NOT RUN: repository checkout / game runtime and iPhone unavailable'}
if __name__=='__main__':
 root=Path(__file__).resolve().parent;result=verify(root);(root/'validation.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
