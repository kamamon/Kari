"""Bake the accepted Spinegale GLB's skeletal animation to Kari 60Hz tracks."""
import json, struct, math, pathlib
import numpy as np
from scipy.spatial.transform import Rotation as R, Slerp
P=pathlib.Path(__file__).parent; OUT=P/'data';OUT.mkdir(exist_ok=True)
GLB=P/'models'/'spinegale_mobile.glb'
with GLB.open('rb') as f:
 f.read(12);n,_=struct.unpack('<II',f.read(8));doc=json.loads(f.read(n));n,_=struct.unpack('<II',f.read(8));buf=f.read(n)
N=doc['nodes'][:77]; IX={n['name']:i for i,n in enumerate(N)}; parent={c:i for i,n in enumerate(N) for c in n.get('children',[])}
rest=np.array([n.get('translation',[0,0,0]) for n in N]); an={a['name']:a for a in doc['animations']}
def acc(i):
 a=doc['accessors'][i];v=doc['bufferViews'][a['bufferView']];n={'SCALAR':1,'VEC3':3,'VEC4':4}[a['type']];return np.frombuffer(buf,dtype='<f4',offset=v.get('byteOffset',0)+a.get('byteOffset',0),count=a['count']*n).reshape(-1,n).astype(float)
from functools import lru_cache
@lru_cache(None)
def frames(name):
 a=an[name];D=a['extras']['durationTicks'];times=np.arange(D+1)/60;ts=np.tile(rest,(D+1,1,1));q=np.zeros((D+1,77,4));q[:,:,3]=1
 for c in a['channels']:
  s=a['samplers'][c['sampler']];x=acc(s['input']).ravel();y=acc(s['output']);t=np.clip(times,x[0],x[-1]);i=c['target']['node']
  if c['target']['path']=='rotation':q[:,i]=Slerp(x,R.from_quat(y))(t).as_quat()
  else:ts[:,i]=np.stack([np.interp(t,x,y[:,j]) for j in range(3)],1)
 rot=R.from_quat(q.reshape(-1,4)).as_matrix().reshape(D+1,77,3,3);world=ts.copy();wr=rot.copy()
 for i in range(77):
  if i in parent:
   j=parent[i];world[:,i]=world[:,j]+np.einsum('tij,tj->ti',wr[:,j],ts[:,i]);wr[:,i]=wr[:,j]@rot[:,i]
 return world,wr
bind=rest.copy()
for i in range(77):
 if i in parent:bind[i]+=bind[parent[i]]
# anchor = bone plus offset in its local axes
B=lambda n,x=0,y=0,z=0:(n,[x,y,z])
def pos(a,f=None,t=0):
 i=IX[a[0]];v=np.array(a[1]);return bind[i]+v if f is None else f[0][t,i]+f[1][t,i]@v
# Multiple skeletal capsule segments on the head, neck, torso, bilateral feet and segmented tail.
parts_cfg=[('head','頭の冠棘',[.65,.70,.55],140,'shell',[(B('head'),B('snout',0,0,.09),.23)]),('dewlap','喉袋',[.75,.65,.65],160,'hide',[(B('dewlap_01'),B('dewlap_03'),.19)]),('spine','背棘',[.35,.50,.30],180,'shell',[(B('dorsal_01',0,.12),B('dorsal_04',0,.12),.21)]),('legs','後脚',[.50,.55,.40],180,'hide',[(B('hind_upper_'+s),B('hock_'+s),.19) for s in ('l','r')]+[(B('hock_'+s),B('toe_middle_tip_'+s),.12) for s in ('l','r')]),('tail','尾扇',[.55,.40,.45],None,'shell',[(B('tail_02'),B('tail_05'),.20),(B('tail_05'),B('tail_08'),.15),(B('tail_08'),B('tail_10',0,0,-.52),.20)]),('body','胴',[.45,.45,.40],None,'hide',[(B('pelvis'),B('chest'),.40),(B('chest'),B('neck_02'),.25)])]
vec=lambda x:np.round(x,5).tolist()
shape=lambda x:{'a':vec(pos(x[0])),'b':vec(pos(x[1])),'r':x[2]}
parts=[]; anchors=[]
for id,name,z,bd,mat,ss in parts_cfg:
 p=dict(id=id,name=name,hitzone=dict(zip(['cut','blunt','shot'],z)),elementZone=.20,breakDurability=bd,material=mat,flinch=dict(threshold=180 if id=='legs' else 140,growth=60,ticks=120 if id=='legs' else 46,**({'topple':True} if id=='legs' else {})),shapes=list(map(shape,ss)))
 if id=='head':p['head']=True
 if bd:p['brokenHitzone']=dict(zip(['cut','blunt','shot'],[min(.95,v+.1) for v in z]))
 if id=='tail':
  p['sever']={'threshold':200,'staggerTicks':92,'shapesAfter':[shape(ss[0])]}
 for i,x in enumerate(ss):anchors.append((id,i,False,x))
 if id=='tail':anchors.append((id,0,True,ss[0]))
 parts.append(p)
# attacks use actual animated anchors; a fixed-length capsule is fitted to each bone segment.
attack_data={'bite':(14,6,'cut','head','snout',.28),'double_bite':(11,12,'cut','head','snout',.28),'dash':(24,20,'blunt','chest','snout',.39),'pounce':(28,22,'blunt','chest','snout',.42),'jump_kick':(26,18,'blunt','metatarsus_l','toe_middle_tip_l',.25),'tail_sweep_l':(18,12,'blunt','tail_06','tail_10',.28),'tail_sweep_r':(18,12,'blunt','tail_06','tail_10',.28),'turn_bite':(17,10,'cut','head','snout',.28),'side_strike_l':(16,12,'blunt','chest','snout',.38),'side_strike_r':(16,12,'blunt','chest','snout',.38),'triple_dash':(12,30,'blunt','chest','snout',.39),'pack_call':(0,8,'blunt','head','snout',.2)}
# 10.5m/s over 66 ticks = 11.55m; sprint pulse distances; side strikes move sideways.
curves_spec={'dash':[(0,0),(30,0),(96,11.55),(132,12.1),(144,12.1)],'pounce':[(0,0),(28,0),(52,4.4),(72,4.7),(132,4.7)],'jump_kick':[(0,0),(26,0),(53,2.4),(80,2.6),(120,2.6)],'side_strike_l':[(0,0),(20,0),(40,2.2),(58,2.4),(96,2.4)],'side_strike_r':[(0,0),(20,0),(40,2.2),(58,2.4),(96,2.4)],'triple_dash':[(0,0),(38,0),(64,4.55),(105,4.55),(130,8.9),(172,8.9),(197,13.25),(240,13.25)],'bite':[(0,0),(24,0),(31,.35),(64,.35)],'double_bite':[(0,0),(26,0),(33,.35),(56,.35),(63,.65),(112,.65)],'turn_bite':[(0,0),(30,0),(40,.4),(88,.4)],'backstep':[(0,0),(15,0),(38,2.4),(55,2.4)]}
base='monster.spinegale.'; actions=[];tracks=[];curves=[];follow={};costs={}
# Full duration from actual GLB; fatigue uses same animation segmented via time mapping for upper ranks.
for name in list(attack_data)+['rage_roar','turn_l','turn_r','pivot_l','pivot_r','backstep','fatigue_full']:
 clip='sg_'+name;D=an[clip]['extras']['durationTicks'];wins=an[clip]['extras']['hitWindows'];f=frames(clip)
 if wins:phase=[{'id':'startup','from':0,'to':wins[0][0]},{'id':'active','from':wins[0][0],'to':wins[-1][1]},{'id':'recovery','from':wins[-1][1],'to':D}]
 else:phase=[{'id':'startup','from':0,'to':D}]
 a={'schemaVersion':1,'actionId':base+name,'clip':clip,'tickRate':60,'durationTicks':D,'phases':phase,'rootMotion':{'mode':'none'},'hitWindows':[],'cancelWindows':[],'events':[],'onFinish':'keep'}
 if name in curves_spec:
  a['rootMotion']={'mode':'controller','curveId':'sg_move_'+name}
  if name in ('side_strike_l','side_strike_r','backstep'):a['rootMotion']['dirDeg']={'side_strike_l':65,'side_strike_r':-65,'backstep':180}[name]
  curves.append({'id':'sg_move_'+name,'keys':curves_spec[name]})
 if name=='dash':a['brake']={'from':30,'to':96}
 if name in ['turn_l','turn_r','pivot_l','pivot_r']:a['spin']={'from':6,'to':D-6,'degrees':(90 if name.startswith('turn') else 180)*(1 if name.endswith('_l') else -1)}
 if name in attack_data:
  dmg,cost,kind,aa,bb,rad=attack_data[name];costs[name]=cost
  if name not in ['tail_sweep_l','tail_sweep_r','side_strike_l','side_strike_r','pack_call']:a['turning']={'untilTick':max(1,wins[0][0]-6),'maxDegreesPerSecond':110}
  if wins:
   aa,bb=B(aa),B(bb,0,0,.10 if bb=='snout' else 0);length=float(np.linalg.norm(pos(bb)-pos(aa)))
   tid='sg_track_'+name;ks=[]
   for t in range(D+1):
    A=pos(aa,f,t);B1=pos(bb,f,t);dr=B1-A;dr=dr/max(1e-7,np.linalg.norm(dr));ks.append({'t':t,'grip':vec(A),'dir':vec(dr)})
   tracks.append({'id':tid,'radius':rad,'from':0,'to':round(length,5),'keys':ks})
   for i,(s,e) in enumerate(wins):a['hitWindows'].append({'id':'strike'+str(i+1),'from':s,'to':e,'shapeTrack':tid,'damageType':kind,'damageCoefficient':1,'maxHitsPerTarget':1,'hitstopTicks':0,'baseDamage':dmg,'guardable':True,'guardCost':dmg+8,'reaction':'knockdown' if dmg>=24 else 'flinch'})
   a['events']=[{'tick':max(0,wins[0][0]-12),'type':'sound','id':'galdros_warn'},{'tick':wins[0][0],'type':'sound','id':'galdros_swing'}]
 if name in ('rage_roar','pack_call'):a['events']=[{'tick':10,'type':'sound','id':'bird_screech'}]
 if name=='fatigue_full':a['events']=[]
 actions.append(a)
 def grid(f,D,step=6):
  ticks=[min(k*step,D-1) for k in range(math.ceil((D-1)/step)+1)];sh=[]
  for part,i,after,(a,b,r) in anchors:
   keys=[np.rint(np.r_[pos(a,f,t)-pos(a),pos(b,f,t)-pos(b)]*100).astype(int).tolist() for t in ticks];sh.append(dict(part=part,i=i,d=keys,**({'after':True} if after else {})))
  return {'shapes':sh}
 follow[a['actionId']]=grid(f,D)
# fatigue is implemented as special deterministic action; normal action scheduler cannot select it.
choices=[]
for name,minD,maxD,angle,weight,cd,clear,side in [('bite',0,2.6,40,3,0,0,None),('double_bite',0,2.9,40,2,240,0,None),('dash',5,13,30,3,240,8,None),('pounce',3.5,7.5,35,3,180,4,None),('jump_kick',1.8,4.8,45,2,180,2,None),('tail_sweep_l',0,4.5,180,2,180,0,'left'),('tail_sweep_r',0,4.5,180,2,180,0,'right'),('turn_bite',0,2.5,85,2,120,0,None),('side_strike_l',1.5,5,135,1.8,180,0,'left'),('side_strike_r',1.5,5,135,1.8,180,0,'right'),('triple_dash',5,13,25,1.1,480,8,None),('pack_call',6,15,60,.7,660,0,None),('backstep',0,2.4,180,1,420,0,None)]:
 c={'actionId':base+name,'minDist':minD,'maxDist':maxD,'maxAngleDeg':angle,'weight':weight}
 if cd:c['cooldownTicks']=cd
 if clear:c['clearAhead']=clear
 if side:c['side']=side;c['minAngleDeg']=35 if name.startswith('side') else 60
 choices.append(c)
# use accepted GLB dimensions and parts. Data for actual game, not a proposal.
monster={'schemaVersion':1,'id':'monster.spinegale','name':'疾棘竜 スパインゲイル','rigFamily':'biped_wing','assetId':'model.monster.spinegale','hp':1450,'bodyRadius':.68,'turnDegPerSec':110,'moveSpeed':2.8,'captureAllowed':True,'weak':['ice','water'],'resist':[],'lootId':'loot.spinegale','lootByRank':{'rank.2':'loot.spinegale.r2','rank.3':'loot.spinegale.r3'},'capture':{'hpRatio':.25,'tranqNeeded':2,'tranqDecayTicks':900},'respawnTicks':None,'breakStaggerTicks':80,'collision':[{'z':0,'r':.58},{'z':-.8,'r':.44}], 'approach':{'stopDist':2.3,'faceDeg':50},'turnSteps':{'faceDeg':50,'backDeg':130,'left':base+'turn_l','right':base+'turn_r','backLeft':base+'pivot_l','backRight':base+'pivot_r'},'discover':{'range':17,'fovDeg':140,'closeRange':6,'actionId':base+'rage_roar'},'rage':{'threshold':420,'durationTicks':1800,'actionId':base+'rage_roar','speedScale':1.15,'damageScale':1.1,'cooldownScale':.8},'parts':parts,'ai':{'aggroRange':200,'cooldownTicks':[20,45],'choices':choices}}
# On severed tail, use a shorter track (same animation but only the proximal segment) with no stale full-tail hit.
for n in ('tail_sweep_l','tail_sweep_r'):
 a=next(x for x in actions if x['actionId']==base+n);D=a['durationTicks'];f=frames(a['clip']);tid='sg_track_'+n+'_short';aa=B('tail_02');bb=B('tail_05');length=float(np.linalg.norm(pos(bb)-pos(aa)));ks=[]
 for t in range(D+1):
  A=pos(aa,f,t);v=pos(bb,f,t)-A;ks.append({'t':t,'grip':vec(A),'dir':vec(v/np.linalg.norm(v))})
 tracks.append({'id':tid,'radius':.21,'from':0,'to':round(length,5),'keys':ks})
 a2=json.loads(json.dumps(a));a2['actionId']+= '_short';a2['hitWindows'][0]['shapeTrack']=tid;a2['hitWindows'][0]['baseDamage']=14;actions.append(a2);follow[a2['actionId']]=follow[a['actionId']];costs[n+'_short']=12
 next(c for c in choices if c['actionId']==a['actionId'])['ifSevered']={'partId':'tail','actionId':a2['actionId']}
# Explicit states: sleep, topple, flinch, stun from animation.
state={}
for kind,clip in [('topple','sg_fall_l'),('flinch','sg_flinch_body'),('stun','sg_stun')]:
 D=an[clip]['extras']['durationTicks'];state[kind]={'ticks':D,**grid(frames(clip),D)}
# output separately for Kari content loader
for file,obj in [('monster.json',monster),('actions.json',{'schemaVersion':1,'actions':actions}),('tracks.json',{'schemaVersion':1,'tracks':tracks}),('curves.json',{'schemaVersion':1,'curves':curves}),('follow.json',{'schemaVersion':1,'monsterId':monster['id'],'step':6,'actions':follow,'states':state,'poses':{'sleep':grid(frames('sg_sleep_loop'),1)}}),('stamina_costs.json',costs)]:
 (OUT/file).write_text(json.dumps(obj,ensure_ascii=False,separators=(',',':'))+'\n')
print('Actions',len(actions),'Tracks',len(tracks),'Follow actions',len(follow),'Parts',len(parts),'Costs',len(costs))
