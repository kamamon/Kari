from pathlib import Path
import json,copy,math
P=Path(__file__).parent; D=P/'data'
load=lambda n:json.loads((D/n).read_text());
def save(n,obj): (D/n).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
manifest=json.loads((P/'icons/manifest.json').read_text()); ids={}; mats=[]; weapons=[];armor=[];recipes=[];quests=[];boards=[];loot=[]
rank={'初級':1,'中級':2,'上級':3}; pref={'weapons':'weapon','armor':'armor','materials':'mat'}
for x in manifest['icons']:
 _,cat,_,kind=x['id'].split('.');r=rank[x['rank']];id=f'{pref[cat]}.{kind}.spinegale.r{r}' if cat!='materials' else f'mat.spinegale.{kind}.r{r}'
 ids[id]=x['path'];x['gameId']=id
 if cat=='materials':mats.append({'id':id,'name':x['name'],'rarity':r+1+(kind in ('crest_bone','sprint_core'))})
 elif cat=='weapons':
  factor={'heavy_blade':.93,'guard_blade':.9,'twin_blades':.88,'long_blade':.92,'war_maul':.94,'long_lance':.93,'ring_bow':.90,'hunting_horn':.93,'gunlance':.93,'light_bowgun':.89,'heavy_bowgun':.95}[kind]
  crit={'heavy_blade':10,'guard_blade':15,'twin_blades':20,'long_blade':15,'war_maul':10,'long_lance':10,'ring_bow':15,'hunting_horn':10,'gunlance':10,'light_bowgun':15,'heavy_bowgun':10}[kind]
  weapons.append({'id':id,'name':x['name'],'family':kind,'attack':round([0,88,103,120][r]*factor),'element':{'type':'none','value':0},'affinity':crit+5*(r-1),'sharpnessModifier':1,'assetId':f'model.weapon.{kind}.001','series':'series.spinegale','rankId':f'rank.{r}'})
  primary={'heavy_blade':'spine','guard_blade':'claw','twin_blades':'claw','long_blade':'spine','war_maul':'spine','long_lance':'spine','ring_bow':'tail_fan','hunting_horn':'dewlap','gunlance':'spine','light_bowgun':'tail_fan','heavy_bowgun':'spine'}[kind]
  ingredients=[('scale',3), (primary,2), ('tendon',1)]+([('crest_bone',1)] if r==2 else [('sprint_core',1)] if r==3 else [])
  recipe={'id':f'recipe.{"craft" if r==1 else "upgrade"}.weapon.spinegale.{kind}.r{r}','kind':'craft' if r==1 else 'upgrade','resultWeaponId':id,'cost':{'money':[0,850,1800,3600][r],'items':[{'itemId':f'mat.spinegale.{k}.r{r}','count':v} for k,v in ingredients]}}
  if r>1:recipe['fromWeaponId']=f'weapon.{kind}.spinegale.r{r-1}'
  recipes.append(recipe)
 else:
  slot=kind;defense={'head':[8,18,33],'chest':[8,18,33],'arms':[7,18,33],'waist':[7,18,33],'legs':[8,18,33]}[slot][r-1]
  skill='dodge_economy' if slot in ('head','arms','legs') else 'stamina_recovery'
  armor.append({'id':id,'slot':slot,'name':x['name'],'defense':defense,'resist':{'ice':-2,'water':-1},'skill':{'id':skill,'points':1},'series':'series.spinegale','rankId':f'rank.{r}'})
  second={'head':'spine','chest':'dewlap','arms':'claw','waist':'tail_fan','legs':'tendon'}[slot]
  ingredients=[('scale',2),(second,1)]+([('crest_bone',1)] if r==2 and slot=='head' else [('sprint_core',1)] if r==3 and slot=='chest' else [])
  recipe={'id':f'recipe.{"craft" if r==1 else "upgrade"}.armor.spinegale.{slot}.r{r}','kind':'armor_craft' if r==1 else 'armor_upgrade','resultArmorId':id,'cost':{'money':[0,450,1100,2200][r],'items':[{'itemId':f'mat.spinegale.{k}.r{r}','count':v} for k,v in ingredients]}}
  if r>1:recipe['fromArmorId']=f'armor.{slot}.spinegale.r{r-1}'
  recipes.append(recipe)
for r in range(1,4):
 def roll(count,vals):return {'count':count,'table':[{'itemId':f'mat.spinegale.{k}.r{r}','weight':v} for k,v in vals]}
 car=[('scale',42),('claw',25),('spine',18),('dewlap',10),('tendon',5)] if r==1 else [('scale',34),('claw',24),('spine',18),('dewlap',10),('tendon',9),('crest_bone',5)] if r==2 else [('scale',32),('claw',23),('spine',18),('dewlap',10),('tendon',10),('crest_bone',6),('sprint_core',1)]
 cap=[('scale',27),('claw',15),('spine',12),('dewlap',18),('tail_fan',8),('tendon',20)] if r==1 else [('scale',25),('claw',14),('spine',11),('dewlap',17),('tail_fan',8),('tendon',17),('crest_bone',8)] if r==2 else [('scale',23),('claw',14),('spine',11),('dewlap',16),('tail_fan',8),('tendon',17),('crest_bone',8),('sprint_core',3)]
 loot.append({'id':'loot.spinegale'+(f'.r{r}' if r>1 else ''),'carve':roll(3,car),'capture':roll(4,cap),'severed':{'tail':roll(1,[('tail_fan',80),('scale',20)])},'breaks':{'head':roll(1,[('spine',70),('scale',30)] if r==1 else [('crest_bone',50),('spine',40),('scale',10)]),'dewlap':roll(1,[('dewlap',100)]),'spine':roll(1,[('spine',100)]),'legs':roll(1,[('claw',65),('tendon',35)] if r<3 else [('claw',60),('tendon',37),('sprint_core',3)])}})
 qid=f'quest.spinegale.r{r}';names=['渓谷を駆ける疾棘','疾風、岩間を裂く','嵐を纏う双尾'];summaries=['風礫盆地の交易路を塞ぐ疾棘竜を一頭狩猟せよ。高速攻撃をかわし、長い息切れを狙う。','背棘の発達した成体が荷道へ戻った。連続突進に注意し、疲労の隙を狙う。','老練な疾棘竜が岩場を縄張りにした。怒りの連撃を見極め、短くなった疲労の隙を逃すな。'];q={'id':qid,'name':names[r-1],'kind':'hunt','summary':summaries[r-1],'mapId':'map.basin.training','fieldId':'field.basin','targetMonsterId':'monster.spinegale','rankId':f'rank.{r}','requires':[['quest.basin.003'],['quest.basin.003','quest.spinegale.r1'],['quest.basin.r2.001','quest.spinegale.r2']][r-1],'monsterSpawn':{'x':4,'z':15,'yaw':2.6},'timeLimitTicks':[54000,108000,144000][r-1],'fieldTimeLimitTicks':[54000,108000,144000][r-1],'maxFaints':3,'returnTicks':3600,'supplies':[{'itemId':'item.heal_tonic','count':5},{'itemId':'item.bind_trap','count':1},{'itemId':'item.calm_orb','count':3},{'itemId':'item.whetstone','count':3}],'rewards':{'money':[700,1600,3200][r-1],'items':[{'itemId':f'mat.spinegale.scale.r{r}','count':1}]}}
 quests.append(q);boards.append({'questId':qid,'stars':[2,4,6][r-1],'lane':'main','client':['里の交易商','峠の荷運び','受付ミナギ'][r-1],'clearMinutes':[[5,8],[9,15],[14,22]][r-1],'text':summaries[r-1]+' 突進の前には腰を沈め、疲れると頭と尾を下げて息を整える。捕獲でも達成できる。'})
# derive exact fatigue variants by remapping the already baked 600tick body follow table
acts=load('actions.json');fol=load('follow.json');base='monster.spinegale.';orig=next(x for x in acts['actions'] if x['actionId']==base+'fatigue_full');old=fol['actions'][orig['actionId']];step=fol['step']
for r,DUR in [(2,540),(3,480)]:
 a=copy.deepcopy(orig);a['actionId']=base+f'fatigue_r{r}';a['durationTicks']=DUR;a['phases']=[{'id':'startup','from':0,'to':DUR}];acts['actions']=[x for x in acts['actions'] if x['actionId']!=a['actionId']]+[a]
 set_=copy.deepcopy(old)
 def remap(t):return t if t<40 else 550+t-(DUR-50) if t>=DUR-50 else 40+(t-40)*510/(DUR-90)
 for sh in set_['shapes']:
  keys=sh['d'];out=[]
  for k in range(math.ceil((DUR-1)/step)+1):
   t=remap(min(k*step,DUR-1));i=min(len(keys)-2,int(t//step));t0=min(i*step,599);t1=min((i+1)*step,599);u=max(0,min(1,(t-t0)/max(1,t1-t0)));out.append([round(x+(y-x)*u) for x,y in zip(keys[i],keys[i+1])])
  sh['d']=out
 fol['actions'][a['actionId']]=set_
# rank settings are explicit, source code reads these via the installer
monster=load('monster.json');monster['spinegaleRank']=1
save('monster.json',monster);save('actions.json',acts);save('follow.json',fol)
save('items.json',{'schemaVersion':1,'items':[],'materials':mats});save('loot.json',{'schemaVersion':1,'tables':loot});save('equipment_all.json',{'schemaVersion':1,'weapons':weapons,'armor':armor,'recipes':recipes});save('quests.json',{'schemaVersion':1,'quests':quests});save('board.json',boards);save('icon_index.json',ids)
(P/'icons/manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
print('materials',len(mats),'weapons',len(weapons),'armor',len(armor),'recipes',len(recipes),'quests',len(quests),'actions',len(acts['actions']))
